=======================================================================
AUTOR'S NOTES:

Thanks for downloading my resourcepack!!
Remember that you will need the MTR and NTE mods to be installed so this resourcepack can work!!

I am always interested to see what you do with my works, so feel free to mention me on my X (Twitter) account @JCIBravo!
Take a look at my web, I publish stuff (photos, new trains or updates, and other interesing stuff...!)
> https://jcibravo.neocities.org 

(Special thanks to Soodari for the 1067mm rail edit and Huli for creating the 3D rail used in the NTE mod)

This resourcepack has MIT license!!

Permissions:
   - Commercial use
   - Distribution
   - Modification
   - Private use

Conditions:
   - License and copyright notice

Limitations:
   - Liability
   - Warranty

=======================================================================
MIT License

Copyright (c) 2024 Joan I. (JCIBravo)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.